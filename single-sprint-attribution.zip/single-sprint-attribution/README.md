# tawos-asof: point-in-time sprint scope for TAWOS

TAWOS stores **one sprint per issue**: for issues that passed through several sprints, the dataset
keeps the first sprint in Jira's sprint list (99.2% of such issues). Work carried over into later
sprints therefore disappears from those sprints, and sprint-level measures computed from the
dataset overstate delivery.

This tool rebuilds, from Jira's change log, the set of issues each sprint held **when it started**
(its committed scope), and compares it with the single-sprint view stored in the dataset.

## Results on TAWOS (requirement items, 1,942 sprints, 26 projects, one-day grace period)

TAWOS keeps the first sprint in the list for 99.2% of the 6,077 requirement items that passed through
two or more sprints. Completion is measured against the planned end of each sprint (+ 24 hours).

| Measure | Dataset view | Committed scope |
|---|---|---|
| Committed issues absent from the sprint in the dataset | — | 59.7% |
| Completion within the sprint (resolved by planned end + 24 h) | 59.1% | 39.5% |
| Sprints with ≥ 90% completion (≥ 5 issues in both views, 999 sprints) | 19.8% | 5.1% |

A sprint-success model using only information known at sprint start (`analysis/sprint_success_model.py`;
story points are taken as they stood at sprint start) predicts committed-scope success with test AUC 0.81,
whereas the predictions of the model for the dataset definition cannot be distinguished from chance (AUC 0.59,
interval including 0.5). Committed story points are the strongest robust predictor under the committed-scope definition
(project-bootstrap 95% interval excluding zero) and have no detectable effect under the dataset definition.

`analysis/sprint_success_robustness.py` checks that this difference does not depend on the test split:
paired bootstrap test of the AUC difference (0.22, 95% interval 0.08 to 0.37, one-sided p = 0.002), training cut-offs
at 60% and 80% of sprints, and Leave-One-Project-Out validation using all successful sprints (AUC 0.78 vs 0.51).

## Re-analysis of an independent study (Zaytsev and Zavrazhnov)

`analysis/reanalysis_zaytsev/` re-runs the analyses of the public reproducibility package of Zaytsev and Zavrazhnov
(https://github.com/maximzavrazhnov/tawos-temporal-integrity-analysis), whose sprint-success outcome is defined on
the final issue set of each sprint, with the same outcome measured on the committed scope. Their own code is read
from their notebook at run time; none of their data or code is redistributed here.

| Measure (833 sprints, grace period 1 day) | Final issue set (their outcome) | Committed scope |
|---|---|---|
| Successful sprints | 141 (16.9%) | 35 (4.2%) |
| Mean completion | 62.2% | 46.6% |
| Pooled LOPO AUC, retrospective model M2 | 0.49 | 0.70 |
| Cross-project LOPO AUC, M2 | 0.47 | 0.70 |

## Replication on the Public Jira Dataset

`extraction/extract_publicjira.py` reads the Public Jira Dataset (Montgomery et al., MSR 2022;
https://doi.org/10.5281/zenodo.15719919) directly from its zip file (MongoDB archive, no MongoDB needed)
and writes `issue_first.csv`, `issue_last.csv`, `sprint.csv` and `change_log.csv`. Sprints are identified
by their Jira IDs, so duplicate names and renames do not arise. To reproduce the replication, copy
`issue_first.csv` (or `issue_last.csv`) as `issue.csv` together with `sprint.csv` and `change_log.csv`
into a data folder and run the tool as above.

| Measure (grace period 1 day) | First-sprint rule | Last-sprint rule |
|---|---|---|
| Sprints compared | 6,487 | 6,501 |
| Committed issues absent from the sprint | 60.0% | 51.2% |
| Completion: single-sprint vs committed scope | 54.6% vs 42.6% | 78.3% vs 42.8% |
| Successful sprints (>= 90%): single-sprint vs committed | 12.4% vs 3.6% | 56.8% vs 3.8% |

## Pitfalls handled (each covered by `tests/test_core.py`)

1. **Unlogged initial sprint.** When an issue is created inside a sprint, Jira does not log that
   assignment (65.5% of requirement items with a sprint history). The initial sprint is recovered from the FROM
   value of the first logged change.
2. **Carry-over keeps closed sprints in the field** (`S1` → `S1, S2`). The field is replayed as a set.
3. **Duplicate sprint names** within a project (201 sprints, 4.4%) cannot be resolved from the history;
   these sprints are excluded.
4. **Renamed sprints** keep their old name in the history. Genuine renames are detected and mapped to
   the current name. They are rare in TAWOS.

A **grace period** (default one day) treats issues added just after a sprint was started as committed,
because teams often finish planning minutes after pressing *Start*.

## Known limitations

* About half of the sprint memberships recorded in the history refer to sprints that are not in the
  TAWOS `Sprint` table (sprints of other boards). Only sprints present in the table are compared.
* Issues with no sprint history are assumed to belong to their dataset sprint if they were created
  before it started.

## Usage

```
# 1. Extract issue.csv, sprint.csv, project.csv and change_log.csv from the TAWOS dump (Windows PowerShell):
#    extraction/extract_tables.ps1  and  extraction/extract_fields.ps1 (use the change_log.csv of the latter);
#    for defect links, extraction/extract_links.ps1, then: python extraction/parse_links.py tawos_links.sql data
#    Public Jira Dataset: python extraction/extract_publicjira.py <zip>; put issue_first.csv (as issue.csv),
#    sprint.csv and change_log.csv in pjd_first, and the same with issue_last.csv in pjd_last
# 2. Reconstruct and compare:
python -m tawos_asof --data data --out out --grace-days 1
# 3. Reproduce the sprint-success analysis (Table 5):
python analysis/sprint_success_model.py --data data --tool-out out
# 4. Reproduce every other number in Sections 3 and 4 of the paper (TAWOS and the Public Jira Dataset):
python analysis/paper_numbers.py --tawos data --pjd-first pjd_first --pjd-last pjd_last --out paper_numbers.json
# 5. Robustness of the sprint-success comparison (Section 4.3):
python analysis/sprint_success_robustness.py --data data --tool-out out
# 6. Re-analysis of Zaytsev and Zavrazhnov (Section 4.3, Table 6); clone their repository first:
#    git clone https://github.com/maximzavrazhnov/tawos-temporal-integrity-analysis zz
#    step 2 uses their code, so use their pinned environment (zz/S4_analysis/environment.txt) and statsmodels
python analysis/reanalysis_zaytsev/build_labels.py --zz-repo zz --data data --out labels.csv
python analysis/reanalysis_zaytsev/reanalyse.py --zz-repo zz --labels labels.csv --grace 1 --out reanalysis.json
# Tests:
python -m pytest tests
```

Outputs: `committed_scope.csv` (issue, sprint pairs at sprint start), `membership_intervals.csv`
(every interval an issue spent in a sprint), `sprint_summary.csv` (per-sprint comparison), `summary.json`.

Requirements: Python 3.9+, pandas, numpy, scikit-learn (analysis only), statsmodels (re-analysis only), pytest (tests only).
