import pandas as pd
from tawos_asof.core import Data, committed_scope, dataset_scope, membership_intervals, detect_renames, sprint_summary

T = pd.Timestamp


def make(issues, sprints, changes):
    i = pd.DataFrame(issues, columns=["ID", "Project_ID", "Type", "Sprint_ID", "created", "resolved"])
    s = pd.DataFrame(sprints, columns=["ID", "Name", "Project_ID", "start", "end"])
    c = pd.DataFrame(changes, columns=["Issue_ID", "From_String", "To_String", "date"])
    return Data(i, s, c.sort_values("date"))


SPRINTS = [(1, "S1", 9, T("2020-01-01"), T("2020-01-14")),
           (2, "S2", 9, T("2020-01-15"), T("2020-01-28")),
           (3, "S3", 9, T("2020-01-29"), T("2020-02-11"))]


def test_unlogged_initial_sprint_is_recovered():
    # created inside S1 (not logged), carried over to S2 at S1's close
    d = make([(10, 9, "story", 1, T("2019-12-20"), T("2020-01-20"))], SPRINTS,
             [(10, "S1", "S1, S2", T("2020-01-14 18:00"))])
    com = committed_scope(d, grace_days=0)
    assert set(zip(com.Issue_ID, com.Sprint_ID)) == {(10, 1), (10, 2)}


def test_carry_over_appends_and_keeps_membership():
    d = make([(11, 9, "story", 1, T("2019-12-20"), None)], SPRINTS,
             [(11, None, "S1", T("2019-12-21")), (11, "S1", "S1, S2", T("2020-01-14")),
              (11, "S1, S2", "S1, S2, S3", T("2020-01-28"))])
    com = committed_scope(d, grace_days=0)
    assert set(com.Sprint_ID) == {1, 2, 3}                    # committed to all three
    assert set(dataset_scope(d).Sprint_ID) == {1}             # dataset keeps only the first


def test_added_after_start_is_not_committed():
    d = make([(12, 9, "task", 2, T("2020-01-10"), T("2020-01-20"))], SPRINTS,
             [(12, None, "S2", T("2020-01-17"))])
    assert committed_scope(d, grace_days=1).empty
    assert len(committed_scope(d, grace_days=3)) == 1         # grace period absorbs late planning


def test_duplicate_sprint_names_are_excluded():
    sprints = SPRINTS + [(4, "S2", 9, T("2021-01-15"), T("2021-01-28"))]
    d = make([(13, 9, "story", 2, T("2020-01-01"), None)], sprints, [(13, None, "S2", T("2020-01-02"))])
    com = committed_scope(d, grace_days=0)
    assert not set(com.Sprint_ID) & {2, 4}


def test_rename_is_mapped_to_current_name():
    sprints = [(5, "EV 18.16 Releasing 1.6", 9, T("2018-08-03"), T("2018-08-17"))]
    issues = [(i, 9, "story", 5, T("2018-07-01"), None) for i in (20, 21)]
    changes = []
    for i in (20, 21):
        changes += [(i, None, "EV 18.16", T("2018-08-01")),
                    (i, "EV 18.16", "EV 18.16 Releasing 1.6", T("2018-08-13 08:45"))]
    d = make(issues, sprints, changes)
    ren = detect_renames(d)
    assert ren[(9, "EV 18.16")] == "EV 18.16 Releasing 1.6"
    com = committed_scope(d, grace_days=0, renames=ren)
    assert set(com.Issue_ID) == {20, 21}                      # committed before the start, under the old name
    assert committed_scope(d, grace_days=0).empty             # without rename handling they would be lost


def test_summary_counts_carried_out_work():
    d = make([(30, 9, "story", 1, T("2019-12-20"), T("2020-01-25")),
              (31, 9, "story", 1, T("2019-12-20"), T("2020-01-05"))], SPRINTS,
             [(30, "S1", "S1, S2", T("2020-01-14 18:00"))])
    s = sprint_summary(d, committed_scope(d, 0), dataset_scope(d)).set_index("Sprint_ID")
    assert s.loc[1, "n_committed"] == 2 and s.loc[1, "completion_committed"] == 0.5
