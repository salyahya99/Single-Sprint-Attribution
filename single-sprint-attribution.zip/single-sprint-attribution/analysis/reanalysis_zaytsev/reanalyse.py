"""Step 2 of the re-analysis of Zaytsev & Zavrazhnov [5]: their analyses with the committed-scope outcome.

Usage: python analysis/reanalysis_zaytsev/reanalyse.py --zz-repo PATH --labels labels.csv --grace 1 --out res.json

Their own code is used, read at run time from their notebook S4_analysis/S4_reproducibility_analysis.ipynb
(code cells 1-9: data loading with their control assertions, model specifications M0-M2, temporal split, metrics,
paired bootstrap; code cells 12-13: Leave-One-Project-Out helpers). Their control assertions check that the
published results are reproduced exactly. Only the outcome column, and for comparability the set of sprints
(those with at least five committed issues), are changed.
Their pinned environment (S4_analysis/environment.txt) should be used: numpy 2.0/2.1, pandas 2.2, scipy 1.16,
scikit-learn 1.6.1, statsmodels 0.14.
"""
import argparse, json, io, contextlib, os
from pathlib import Path
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser(); ap.add_argument("--zz-repo", required=True); ap.add_argument("--labels", required=True)
ap.add_argument("--grace", type=int, default=1, choices=(0, 1, 3)); ap.add_argument("--out", required=True)
a = ap.parse_args()
nb = json.load(open(os.path.join(a.zz_repo, "S4_analysis", "S4_reproducibility_analysis.ipynb"), encoding="utf-8"))
cells = ["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code"]
ns = {}
here = repr(str(Path(a.zz_repo, "S4_analysis").resolve()))
with contextlib.redirect_stdout(io.StringIO()):
    exec("\n\n".join(cells[:9]).replace("HERE = Path.cwd()", f"HERE = Path({here})"), ns)
    exec(cells[11].split("\nlopo_preds=")[0], ns)
    exec(cells[12].split("\nproj_tables={}")[0], ns)
print("their published control values reproduced (notebook assertions passed)")
globals().update({k: ns[k] for k in ("df", "FEATURES", "temporal_split", "temporal_predictions", "metric_row",
                                     "paired_stratified_bootstrap", "leave_one_group_out", "project_auc_table",
                                     "cross_project_pair_auc", "roc_auc_score")})
g = a.grace
lab = pd.read_csv(a.labels)
full = df.merge(lab[["Sprint_ID", f"n_committed_g{g}", f"share_committed_g{g}", "share_dataset"]], on="Sprint_ID", how="left")
full["y_dataset"] = full.success_90_end24
full["y_committed"] = (full[f"share_committed_g{g}"] >= 0.9 - 1e-12).astype(int)
known = full.share_dataset.notna()
assert ((full.share_dataset[known] >= 0.9 - 1e-12).astype(int) == full.y_dataset[known]).all()

R = full[full[f"n_committed_g{g}"] >= 5].reset_index(drop=True)
res = {"grace_days": g, "n_all": len(full), "n_cohort": len(R), "projects": int(R.Project_Key.nunique()),
       "excluded_no_committed": int(full[f"n_committed_g{g}"].isna().sum()),
       "excluded_lt5": int((full[f"n_committed_g{g}"] < 5).sum()),
       "success_dataset": int(R.y_dataset.sum()), "success_committed": int(R.y_committed.sum()),
       "rate_dataset": R.y_dataset.mean(), "rate_committed": R.y_committed.mean(),
       "dataset_success_failing_committed": int(((R.y_dataset == 1) & (R.y_committed == 0)).sum()),
       "committed_only_success": int(((R.y_dataset == 0) & (R.y_committed == 1)).sum()),
       "flipped": int((R.y_dataset != R.y_committed).sum()),
       "mean_completion_dataset": R.share_dataset.mean(), "mean_completion_committed": R[f"share_committed_g{g}"].mean()}
pr = R.groupby("Project_Key")[["y_dataset", "y_committed"]].sum()
res["projects_no_success_dataset"] = int((pr.y_dataset == 0).sum())
res["projects_no_success_committed"] = int((pr.y_committed == 0).sum())


def evaluate(data, outcome):
    data = data.copy(); data["success_90_end24"] = data[outcome]   # their helpers read this column
    tr, te = temporal_split(data)
    o = {"train": len(tr), "test": len(te), "test_successful": int(te.success_90_end24.sum())}
    preds = temporal_predictions(tr, te)
    o["holdout"] = {m: {k: float(v) for k, v in metric_row(te.success_90_end24, p).items()} for m, p in preds.items()}
    boot = paired_stratified_bootstrap(te.success_90_end24, preds)
    o["holdout_auc_ci"] = {m: list(map(float, np.quantile(boot[f"{m}_ROC_AUC"], [.025, .975]))) for m in FEATURES}
    data = data.reset_index(drop=True)
    lp = leave_one_group_out(data, "Project_Key")
    o["lopo"] = {}
    for m, p in lp.items():
        t = project_auc_table(data, p).dropna(subset=["ROC_AUC"])
        o["lopo"][m] = {"pooled": float(roc_auc_score(data.success_90_end24, p)),
                        "within_pair_weighted": float(np.average(t.ROC_AUC, weights=t.PairWeight)),
                        "cross_project_pairs": float(cross_project_pair_auc(data, p))}
    return o


res["their_cohort_their_outcome"] = evaluate(full, "y_dataset")
res["same_sprints_their_outcome"] = evaluate(R, "y_dataset")
res["same_sprints_committed_outcome"] = evaluate(R, "y_committed")
json.dump(res, open(a.out, "w"), indent=1, default=float)
for k, v in res.items():
    if not isinstance(v, dict): print(f"{k}: {v:.3f}" if isinstance(v, float) else f"{k}: {v}")
for k in ("their_cohort_their_outcome", "same_sprints_their_outcome", "same_sprints_committed_outcome"):
    e = res[k]; print(f"\n== {k}: test sprints {e['test']}, successful {e['test_successful']}")
    for m in FEATURES:
        h, L = e["holdout"][m], e["lopo"][m]
        print(f"  {m}: holdout AUC {h['ROC_AUC']:.3f} | LOPO pooled {L['pooled']:.3f}, within {L['within_pair_weighted']:.3f},"
              f" cross-project {L['cross_project_pairs']:.3f}")
