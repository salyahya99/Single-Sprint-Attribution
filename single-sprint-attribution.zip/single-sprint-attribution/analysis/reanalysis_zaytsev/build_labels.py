"""Step 1 of the re-analysis of Zaytsev & Zavrazhnov [5]: committed-scope outcomes for their 952 sprints.

Usage: python analysis/reanalysis_zaytsev/build_labels.py --zz-repo PATH --data DIR --out labels.csv
  --zz-repo  clone of https://github.com/maximzavrazhnov/tawos-temporal-integrity-analysis
  --data     folder with the TAWOS issue.csv, sprint.csv and change_log.csv used by tawos_asof

Their outcome (success_90_end24): >= 90% of the sprint's issues resolved no later than 24 h after the planned end,
over the issues whose final TAWOS Sprint_ID is the sprint (all issue types); a resolution counts only if
Resolution_Date >= Creation_Date (or Creation_Date is missing). The same rule is applied here to the committed
scope (all issue types) for grace periods of 0, 1 and 3 days. The script first checks that the rule, applied to the
dataset scope, reproduces their resolved share for every sprint.
"""
import argparse, os, sys
import pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from tawos_asof.core import load, detect_renames, committed_scope, dataset_scope, ambiguous_sprints

ap = argparse.ArgumentParser(); ap.add_argument("--zz-repo", required=True); ap.add_argument("--data", required=True)
ap.add_argument("--out", required=True); a = ap.parse_args()
z = pd.read_csv(os.path.join(a.zz_repo, "S3_data", "S3_modeling_dataset.csv"), parse_dates=["Start_Date", "End_Date"])
d = load(*(os.path.join(a.data, f) for f in ("issue.csv", "sprint.csv", "change_log.csv")), types=None)
ren = detect_renames(d)
amb = ambiguous_sprints(d.sprints)
iss = d.issues.set_index("ID")
ok_res = iss.resolved.notna() & (iss.created.isna() | (iss.resolved >= iss.created))
end = z.set_index("Sprint_ID").End_Date


def label(pairs, tag):
    p = pairs[pairs.Sprint_ID.isin(z.Sprint_ID)].copy()
    r = iss.resolved.reindex(p.Issue_ID).to_numpy()
    good = ok_res.reindex(p.Issue_ID).to_numpy()
    p["done"] = good & (r <= (end.reindex(p.Sprint_ID) + pd.Timedelta(hours=24)).to_numpy())
    return p.groupby("Sprint_ID").done.agg(["size", "mean"]).rename(columns={"size": f"n_{tag}", "mean": f"share_{tag}"})


fin = dataset_scope(d)
out = z[["Project_Key", "Sprint_ID", "success_90_end24", "resolved_by_end24_share", "issue_count",
         "stable_from_start_flag"]].set_index("Sprint_ID")
out = out.join(label(fin, "dataset"))
coms = {}
for g in (0, 1, 3):
    coms[g] = committed_scope(d, g, ren)
    out = out.join(label(coms[g], f"committed_g{g}"))
out["ambiguous_name"] = out.index.isin(amb)

chk = out[~out.ambiguous_name]
assert (chk.n_dataset == chk.issue_count).all(), "dataset scope differs from their issue set"
assert ((chk.share_dataset - chk.resolved_by_end24_share).abs() < 1e-4).all(), "resolved share not reproduced"
print(f"check passed: their issue set and resolved share reproduced for all {len(chk)} sprints with unique names")

# committed issues absent from the final issue set (grace period 1 day, sprints with >= 5 committed issues)
c = coms[1][coms[1].Sprint_ID.isin(z.Sprint_ID)].copy()
fp = set(zip(fin.Issue_ID, fin.Sprint_ID))
c["absent"] = [(i, s) not in fp for i, s in zip(c.Issue_ID, c.Sprint_ID)]
g = c.groupby("Sprint_ID").absent.agg(["sum", "size", "mean"]); g = g[g["size"] >= 5]
print(f"committed issues absent from the final issue set: mean per sprint {g['mean'].mean():.1%} "
      f"({len(g)} sprints; {(g['sum'] > 0).mean():.1%} of sprints have at least one)")
st = out.index[out.stable_from_start_flag == 1]
print("sprints they classify as stable from the start:", [int(s) for s in st], "-> absent committed issues:", [int(x) for x in g["sum"].reindex(st)])
for gg in (0, 1, 3):
    n = out[f"n_committed_g{gg}"]
    print(f"grace {gg} d: no committed scope {int(n.isna().sum())}, fewer than 5 committed issues {int((n < 5).sum())}")
# only TAWOS-derived columns are written (none of the original study's data)
keep = [c for c in out.columns if c.startswith(("n_", "share_"))] + ["ambiguous_name"]
out[keep].reset_index().to_csv(a.out, index=False)
