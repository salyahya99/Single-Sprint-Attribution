"""Sprint-success prediction under the dataset definition and the committed-scope definition.

Usage: python analysis/sprint_success_model.py --data DIR --tool-out DIR
Features are known at sprint start and computed from the committed scope; the outcome is defined
either on the dataset scope (one sprint per issue) or on the committed scope.
"""
import argparse, os
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score

ap = argparse.ArgumentParser(); ap.add_argument("--data", required=True); ap.add_argument("--tool-out", required=True)
ap.add_argument("--boot", type=int, default=1000); ap.add_argument("--grace-days", type=float, default=1.0)
a = ap.parse_args()
iss = pd.read_csv(os.path.join(a.data, "issue.csv"), low_memory=False)[["ID", "Story_Point"]]
final_sp = pd.to_numeric(iss.set_index("ID").Story_Point, errors="coerce")
# story points as they stood at sprint start (+ grace), reconstructed from the change log
ch = pd.read_csv(os.path.join(a.data, "change_log.csv"), low_memory=False, usecols=["Issue_ID", "Field", "From_String", "Creation_Date"])
ch = ch[ch.Field.astype(str).str.lower().str.strip() == "story points"].copy()
ch["date"] = pd.to_datetime(ch.Creation_Date, errors="coerce"); ch = ch.dropna(subset=["date"]).sort_values("date")
hist = {i: (g.date.values, g.From_String.values) for i, g in ch.groupby("Issue_ID")}
def sp_at(i, t):
    if i in hist:
        d, f = hist[i]; k = np.searchsorted(d, np.datetime64(t), side="right")
        if k < len(d):
            return pd.to_numeric(f[k], errors="coerce")
    return final_sp.get(i)
com = pd.read_csv(os.path.join(a.tool_out, "committed_scope.csv"))
S = pd.read_csv(os.path.join(a.tool_out, "sprint_summary.csv"), parse_dates=["start", "end"])
c = com.merge(S[["Sprint_ID", "start"]], on="Sprint_ID")
c["sp"] = [sp_at(i, t + pd.Timedelta(days=a.grace_days)) for i, t in zip(c.Issue_ID, c.start)]
c["carry_in"] = c.start > c.Issue_ID.map(c.groupby("Issue_ID").start.min())
f = c.groupby("Sprint_ID").agg(log_items=("Issue_ID", lambda s: np.log1p(len(s))), log_sp=("sp", lambda s: np.log1p(s.fillna(0).sum())),
                               sp_missing=("sp", lambda s: s.isna().mean()), carry_in=("carry_in", "mean"))
D = S.set_index("Sprint_ID").join(f, how="inner")
D = D[(D.n_committed >= 5) & (D.n_dataset >= 5)].copy()
D["days"] = (D.end - D.start).dt.days.clip(1, 60)
X = ["log_items", "log_sp", "sp_missing", "carry_in", "days"]
tr = D.start < D.start.quantile(0.7); te = ~tr; rng = np.random.default_rng(3)
print(f"sprints {len(D)} | success: dataset definition {D.success_dataset.mean():.1%}, committed definition {D.success_committed.mean():.1%}")
for y in ["success_dataset", "success_committed"]:
    sc = StandardScaler().fit(D.loc[tr, X]); m = LogisticRegression(max_iter=2000).fit(sc.transform(D.loc[tr, X]), D.loc[tr, y])
    p = m.predict_proba(sc.transform(D.loc[te, X]))[:, 1]; yt = D.loc[te, y].values; b = []
    for _ in range(a.boot):
        i = rng.integers(0, len(yt), len(yt))
        if yt[i].min() != yt[i].max(): b.append(roc_auc_score(yt[i], p[i]))
    print(f"\n{y}: test AUC {roc_auc_score(yt, p):.3f} [{np.percentile(b, 2.5):.3f}, {np.percentile(b, 97.5):.3f}]")
    proj = D.Project_ID.unique(); co = []
    for _ in range(a.boot):
        B = pd.concat([D[D.Project_ID == q] for q in rng.choice(proj, len(proj))])
        if B[y].nunique() < 2: continue
        s2 = StandardScaler().fit(B[X]); co.append(LogisticRegression(max_iter=2000).fit(s2.transform(B[X]), B[y]).coef_[0])
    co = np.array(co)
    for k, n in enumerate(X):
        lo, hi = np.percentile(co[:, k], [2.5, 97.5]); print(f"   {n:11s} {np.median(co[:, k]):+.2f} [{lo:+.2f}, {hi:+.2f}]{'  *' if lo > 0 or hi < 0 else ''}")
