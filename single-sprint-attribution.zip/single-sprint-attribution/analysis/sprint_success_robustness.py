"""Robustness of the sprint-success comparison (Section 4.3).

Usage: python analysis/sprint_success_robustness.py --data DIR --tool-out DIR
Same sprints, predictors and model as analysis/sprint_success_model.py. Reports
(a) a paired bootstrap test of the difference between the two test AUCs (same 30% test sprints),
(b) the test AUCs for training cut-offs at 60%, 70% and 80% of sprints, and
(c) Leave-One-Project-Out (LOPO) AUC pooled over all sprints, with a project-bootstrap interval.
"""
import argparse, os
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score

ap = argparse.ArgumentParser(); ap.add_argument("--data", required=True); ap.add_argument("--tool-out", required=True)
ap.add_argument("--boot", type=int, default=2000); ap.add_argument("--grace-days", type=float, default=1.0)
a = ap.parse_args()

# ---- sprint features: identical to analysis/sprint_success_model.py ----
iss = pd.read_csv(os.path.join(a.data, "issue.csv"), low_memory=False)[["ID", "Story_Point"]]
final_sp = pd.to_numeric(iss.set_index("ID").Story_Point, errors="coerce")
ch = pd.read_csv(os.path.join(a.data, "change_log.csv"), low_memory=False, usecols=["Issue_ID", "Field", "From_String", "Creation_Date"])
ch = ch[ch.Field.astype(str).str.lower().str.strip() == "story points"].copy()
ch["date"] = pd.to_datetime(ch.Creation_Date, errors="coerce"); ch = ch.dropna(subset=["date"]).sort_values("date")
hist = {i: (g.date.values, g.From_String.values) for i, g in ch.groupby("Issue_ID")}
def sp_at(i, t):
    if i in hist:
        d, f = hist[i]; k = np.searchsorted(d, np.datetime64(t), side="right")
        if k < len(d):
            return pd.to_numeric(f[k], errors="coerce")
    return final_sp.get(i)
com = pd.read_csv(os.path.join(a.tool_out, "committed_scope.csv"))
S = pd.read_csv(os.path.join(a.tool_out, "sprint_summary.csv"), parse_dates=["start", "end"])
c = com.merge(S[["Sprint_ID", "start"]], on="Sprint_ID")
c["sp"] = [sp_at(i, t + pd.Timedelta(days=a.grace_days)) for i, t in zip(c.Issue_ID, c.start)]
c["carry_in"] = c.start > c.Issue_ID.map(c.groupby("Issue_ID").start.min())
f = c.groupby("Sprint_ID").agg(log_items=("Issue_ID", lambda s: np.log1p(len(s))), log_sp=("sp", lambda s: np.log1p(s.fillna(0).sum())),
                               sp_missing=("sp", lambda s: s.isna().mean()), carry_in=("carry_in", "mean"))
D = S.set_index("Sprint_ID").join(f, how="inner")
D = D[(D.n_committed >= 5) & (D.n_dataset >= 5)].copy()
D["days"] = (D.end - D.start).dt.days.clip(1, 60)
X = ["log_items", "log_sp", "sp_missing", "carry_in", "days"]
YS = ["success_dataset", "success_committed"]


def fitpred(trm, tem, y):
    sc = StandardScaler().fit(D.loc[trm, X]); m = LogisticRegression(max_iter=2000).fit(sc.transform(D.loc[trm, X]), D.loc[trm, y])
    return m.predict_proba(sc.transform(D.loc[tem, X]))[:, 1]


print(f"sprints {len(D)} | successful: dataset {int(D.success_dataset.sum())}, committed {int(D.success_committed.sum())}")
# (a) paired bootstrap of the AUC difference
tr = D.start < D.start.quantile(0.7); te = ~tr
P = {y: fitpred(tr, te, y) for y in YS}; Y = {y: D.loc[te, y].values.astype(int) for y in YS}
auc = {y: roc_auc_score(Y[y], P[y]) for y in YS}
rng = np.random.default_rng(3); n = int(te.sum()); diff = []
for _ in range(a.boot):
    i = rng.integers(0, n, n)
    if all(Y[y][i].min() != Y[y][i].max() for y in YS):
        diff.append(roc_auc_score(Y["success_committed"][i], P["success_committed"][i]) -
                    roc_auc_score(Y["success_dataset"][i], P["success_dataset"][i]))
diff = np.array(diff)
print(f"(a) test sprints {n}; AUC committed {auc['success_committed']:.3f}, dataset {auc['success_dataset']:.3f}; "
      f"difference {auc['success_committed'] - auc['success_dataset']:.3f} "
      f"[{np.percentile(diff, 2.5):.3f}, {np.percentile(diff, 97.5):.3f}], one-sided p = {(diff <= 0).mean():.4f}")
# (b) other temporal cut-offs
for q in (0.6, 0.7, 0.8):
    tr = D.start < D.start.quantile(q); te = ~tr
    r = {y: (roc_auc_score(D.loc[te, y], fitpred(tr, te, y)), int(D.loc[te, y].sum())) for y in YS}
    print(f"(b) training cut-off {q:.0%}: " + "; ".join(f"{y} AUC {v:.3f} ({p} successful test sprints)" for y, (v, p) in r.items()))
# (c) LOPO
projs = D.Project_ID.unique()
for y in YS:
    p = pd.Series(np.nan, index=D.index)
    for q in projs:
        tem = D.Project_ID == q
        if D.loc[~tem, y].nunique() == 2:
            p[tem] = fitpred(~tem, tem, y)
    ok = p.notna(); v = roc_auc_score(D.loc[ok, y], p[ok]); b = []; rng = np.random.default_rng(3)
    for _ in range(1000):
        B = np.concatenate([np.flatnonzero((D.Project_ID == g).values & ok.values) for g in rng.choice(projs, len(projs))])
        yy = D[y].values[B]
        if yy.min() != yy.max(): b.append(roc_auc_score(yy, p.values[B]))
    print(f"(c) LOPO {y}: pooled AUC {v:.3f} [{np.percentile(b, 2.5):.3f}, {np.percentile(b, 97.5):.3f}] "
          f"({int(D[y].sum())} successful sprints)")
