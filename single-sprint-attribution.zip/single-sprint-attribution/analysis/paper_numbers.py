"""Reproduce every number reported in Sections 3 and 4 of the paper.

Usage:
    python analysis/paper_numbers.py --tawos DIR --pjd-first DIR --pjd-last DIR --out results.json

--tawos      issue.csv, sprint.csv, project.csv, issue_link.csv and change_log.csv
             (change_log.csv with From_String/To_String for the Sprint and Story Points fields,
             as produced by extraction/extract_tables.ps1, extract_fields.ps1 and extract_links.ps1)
--pjd-first  issue.csv (= issue_first.csv), sprint.csv, change_log.csv from extract_publicjira.py
--pjd-last   the same with issue.csv = issue_last.csv

Definitions (as in the paper):
  * completion: share of a scope's issues resolved no later than the planned end + 24 h;
  * success: completion >= threshold, for sprints with >= 5 issues in both scopes;
  * carried over: an item in the committed scope of two or more sprints (all reconstructed sprints);
  * story points at first commitment: value at the start of the item's first committed sprint + grace;
  * sign tests exclude ties.
The sprint-success model (Table 5) is produced by analysis/sprint_success_model.py.
"""
import argparse, json, os, sys
import numpy as np, pandas as pd
from scipy import stats

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from tawos_asof.core import (load, detect_renames, membership_intervals, committed_scope, dataset_scope,
                             sprint_summary, ambiguous_sprints, _split)

REQ = ("story", "task", "improvement", "new feature")
TOL = pd.Timedelta(hours=24)


def sign_test(k, n):
    return float(stats.binomtest(k, n, 0.5).pvalue) if n else float("nan")


def run_tool(data, grace, dedupe=False):
    d = load(*(os.path.join(data, f) for f in ("issue.csv", "sprint.csv", "change_log.csv")), types=REQ)
    if dedupe:   # the Public Jira archive contains a few issues and changes twice
        d.raw_counts = (len(d.issues), len(d.changes))
        d.issues = d.issues.drop_duplicates("ID"); d.changes = d.changes.drop_duplicates()
    ren = detect_renames(d)
    com = committed_scope(d, grace, ren)
    fin = dataset_scope(d)
    S = sprint_summary(d, com, fin)
    return d, ren, com, fin, S


def delivery(d, com, fin, S):
    """Section 4.1 / Table 2, 3 and 6 measures."""
    o = {"sprints": len(S), "projects": int(S.Project_ID.nunique())}
    o["committed_absent"] = S.carried_out.sum() / S.n_committed.sum()
    o["dataset_not_committed"] = S.added_after_start.sum() / S.n_dataset.sum()
    o["completion_dataset"] = (S.completion_dataset * S.n_dataset).sum() / S.n_dataset.sum()
    o["completion_committed"] = (S.completion_committed * S.n_committed).sum() / S.n_committed.sum()
    E = S[(S.n_dataset >= 5) & (S.n_committed >= 5)]
    o["sprints_n5"] = len(E)
    for t in (0.8, 0.9, 1.0):
        o[f"success_dataset_{int(t*100)}"] = float((E.completion_dataset >= t - 1e-12).mean())
        o[f"success_committed_{int(t*100)}"] = float((E.completion_committed >= t - 1e-12).mean())
    diff = S.completion_dataset - S.completion_committed
    o["sprints_higher"], o["sprints_same"], o["sprints_lower"] = (float((diff > 1e-12).mean()),
                                                                 float((diff.abs() <= 1e-12).mean()),
                                                                 float((diff < -1e-12).mean()))
    o["wilcoxon_p"] = float(stats.wilcoxon(S.completion_dataset, S.completion_committed).pvalue)
    pj = S.groupby("Project_ID").apply(lambda g: pd.Series({
        "n": len(g), "absent": g.carried_out.sum() / g.n_committed.sum(),
        "gap": (g.completion_dataset * g.n_dataset).sum() / g.n_dataset.sum()
               - (g.completion_committed * g.n_committed).sum() / g.n_committed.sum()}))
    o["project_absent_min"], o["project_absent_median"], o["project_absent_max"] = (
        float(pj.absent.min()), float(pj.absent.median()), float(pj.absent.max()))
    o["projects_overstated"] = int((pj.gap > 0).sum())
    o["projects_understated"] = {str(k): {"sprints": int(v.n), "gap_pp": round(100 * v.gap, 1)}
                                 for k, v in pj[pj.gap < 0].iterrows()}
    o["project_gap_median_pp"] = float(100 * pj.gap.median())
    o["projects_20plus"] = int((pj.n >= 20).sum()); o["projects_20plus_overstated"] = int(((pj.n >= 20) & (pj.gap > 0)).sum())
    o["largest_project_share"] = float(pj.n.max() / len(S))
    # unfinished vs finished committed issues omitted
    res = dict(zip(d.issues.ID, d.issues.resolved)); end = dict(zip(S.Sprint_ID, S.end))
    keep = set(S.Sprint_ID); fp = set(zip(fin.Issue_ID, fin.Sprint_ID))
    C = com[com.Sprint_ID.isin(keep)].copy()
    C["done"] = [pd.notna(res.get(i)) and res.get(i) <= end[s] + TOL for i, s in zip(C.Issue_ID, C.Sprint_ID)]
    C["omitted"] = [(i, s) not in fp for i, s in zip(C.Issue_ID, C.Sprint_ID)]
    o["omitted_unfinished"] = float(C[~C.done].omitted.mean()); o["omitted_finished"] = float(C[C.done].omitted.mean())
    C["Project_ID"] = C.Sprint_ID.map(dict(zip(S.Sprint_ID, S.Project_ID)))
    a = C.groupby("Project_ID").apply(lambda g: g[~g.done].omitted.mean() - g[g.done].omitted.mean()).dropna()
    k, n = int((a > 0).sum()), int((a != 0).sum())
    o["asymmetry_projects"] = f"{k} of {len(a)} ({len(a) - n} tied)"; o["asymmetry_sign_p"] = sign_test(k, n)
    return o, C


def tawos_extra(d, ren, com, fin, S, C, data):
    o = {}
    spr = pd.read_csv(os.path.join(data, "sprint.csv"))
    sstart = dict(zip(d.sprints.ID, d.sprints.start))
    stored = dict(zip(d.issues.ID, d.issues.Sprint_ID))
    # where the committed issues that the dataset omits are recorded
    ab = C[C.omitted]
    def where(i, s):
        ds = stored.get(i)
        if pd.isna(ds): return "none"
        a, b = sstart.get(ds), sstart.get(s)
        if a is None or pd.isna(a): return "undated"
        return "earlier" if a < b else "later" if a > b else "same"
    o["absent_recorded_in"] = pd.Series([where(i, s) for i, s in zip(ab.Issue_ID, ab.Sprint_ID)]).value_counts(normalize=True).round(4).to_dict()
    # overstated sprints: omitted committed issues and added issues
    over = set(S[S.completion_dataset > S.completion_committed + 1e-12].Sprint_ID)
    o["overstated_omitted_resolved"] = float(C[C.Sprint_ID.isin(over) & C.omitted].done.mean())
    res = dict(zip(d.issues.ID, d.issues.resolved)); end = dict(zip(S.Sprint_ID, S.end))
    cp = set(zip(com.Issue_ID, com.Sprint_ID))
    ad = fin[fin.Sprint_ID.isin(over)]; ad = ad[[(i, s) not in cp for i, s in zip(ad.Issue_ID, ad.Sprint_ID)]].copy()
    ad["done"] = [pd.notna(res.get(i)) and res.get(i) <= end[s] + TOL for i, s in zip(ad.Issue_ID, ad.Sprint_ID)]
    o["overstated_added_resolved"] = float(ad.done.mean())
    iv = membership_intervals(d, ren)
    name = dict(zip(d.sprints.ID, d.sprints.Name))
    ad["name"] = ad.Sprint_ID.map(name)
    m = ad.merge(iv[["Issue_ID", "name", "t_in"]], on=["Issue_ID", "name"]).groupby(["Issue_ID", "Sprint_ID"]).t_in.max().reset_index()
    m["res"] = m.Issue_ID.map(res)
    o["overstated_added_entry_recorded"] = len(m)
    o["overstated_added_resolved_before_entry"] = float((m.res.notna() & (m.res < m.t_in)).mean())
    # hidden work: all items committed to at least one reconstructed sprint
    amb = ambiguous_sprints(d.sprints)
    cs = com.copy(); cs["start"] = cs.Sprint_ID.map(sstart)
    it = cs.groupby("Issue_ID").agg(n=("Sprint_ID", "nunique"), first=("start", "min"))
    it["carried"] = it.n >= 2
    o["items_committed"] = len(it); o["items_carried"] = int(it.carried.sum()); o["carried_share"] = float(it.carried.mean())
    o["carried_sprints_median"] = float(it[it.carried].n.median())
    o["carried_sprints_iqr"] = [float(x) for x in it[it.carried].n.quantile([.25, .75])]
    o["carried_sprints_max"] = int(it.n.max())
    ch = pd.read_csv(os.path.join(data, "change_log.csv"), low_memory=False)
    ch = ch[ch.Field.astype(str).str.lower().str.strip() == "story points"].copy()
    ch["date"] = pd.to_datetime(ch.Creation_Date, errors="coerce"); ch = ch.dropna(subset=["date"]).sort_values("date", kind="stable")
    hist = {i: (g.date.values, g.From_String.values) for i, g in ch.groupby("Issue_ID")}
    iss = pd.read_csv(os.path.join(data, "issue.csv"), low_memory=False).set_index("ID")
    final_sp = pd.to_numeric(iss.Story_Point, errors="coerce")
    def sp_at(i, t):
        if i in hist:
            dd, ff = hist[i]; k = np.searchsorted(dd, np.datetime64(t), side="right")
            if k < len(dd): return pd.to_numeric(ff[k], errors="coerce")
        return final_sp.get(i)
    grace = pd.Timedelta(days=1)
    it["sp0"] = [sp_at(i, t + grace) for i, t in zip(it.index, it["first"])]
    it["spf"] = it.index.map(final_sp)
    it["sp_changed"] = [(pd.isna(a) != pd.isna(b)) or (pd.notna(a) and float(a) != float(b)) for a, b in zip(it.sp0, it.spf)]
    g1, g0 = it[it.carried], it[~it.carried]
    o["sp_final_differs"] = [float(g1.sp_changed.mean()), float(g0.sp_changed.mean())]
    o["sp_median"] = [float(g1.sp0.median()), float(g0.sp0.median())]
    o["sp_mannwhitney_p"] = float(stats.mannwhitneyu(g1.sp0.dropna(), g0.sp0.dropna()).pvalue)
    o["sp_missing"] = [float(g1.sp0.isna().mean()), float(g0.sp0.isna().mean())]
    lnk = pd.read_csv(os.path.join(data, "issue_link.csv"), low_memory=False)
    bugs = set(iss.index[iss.Type.astype(str).str.lower() == "bug"])
    pairs = np.concatenate([lnk[["Issue_ID", "Target_Issue_ID"]].values, lnk[["Target_Issue_ID", "Issue_ID"]].values])
    linked = {a for a, b in pairs if b in bugs}
    it["defect"] = it.index.isin(linked)
    o["defect_linked"] = [float(g1.index.isin(linked).mean()), float(g0.index.isin(linked).mean())]
    o["defect_chi2_p"] = float(stats.chi2_contingency(pd.crosstab(it.carried, it.defect))[1])
    it["type"] = it.index.map(iss.Type.astype(str).str.lower())
    o["carried_share_by_type"] = it.groupby("type").carried.mean().round(4).to_dict()
    it["P"] = it.index.map(iss.Project_ID)
    hi = lo = eq = 0
    for _, g in it.groupby("P"):
        a, b = g[g.carried].sp0.dropna(), g[~g.carried].sp0.dropna()
        if len(a) >= 5 and len(b) >= 5:
            hi += a.median() > b.median(); lo += a.median() < b.median(); eq += a.median() == b.median()
    o["sp_within_projects"] = {"projects": int(hi + lo + eq), "higher": int(hi), "lower": int(lo), "same": int(eq), "sign_p": sign_test(int(hi), int(hi + lo))}
    hi = lo = eq = 0
    for _, g in it.groupby("P"):
        if g.carried.any() and (~g.carried).any():
            x, y = g[g.carried].defect.mean(), g[~g.carried].defect.mean(); hi += x > y; lo += x < y; eq += x == y
    o["defect_within_projects"] = {"projects": int(hi + lo + eq), "higher": int(hi), "lower": int(lo), "same": int(eq), "sign_p": sign_test(int(hi), int(hi + lo))}
    # sprint-success sample (Section 4.3)
    E = S[(S.n_committed >= 5) & (S.n_dataset >= 5)]
    te = E[~(E.start < E.start.quantile(0.7))]
    o["model_sprints"] = len(E); o["model_success_dataset"] = int(E.success_dataset.sum())
    o["model_success_committed"] = int(E.success_committed.sum()); o["model_test_sprints"] = len(te)
    o["model_test_success_committed"] = int(te.success_committed.sum())
    return o


def tawos_data(d, data, ren):
    """Section 3.1-3.3 descriptives for TAWOS."""
    o = {}
    allis = pd.read_csv(os.path.join(data, "issue.csv"), low_memory=False)
    spr = pd.read_csv(os.path.join(data, "sprint.csv"))
    o["issues"] = len(allis); o["projects"] = int(allis.Project_ID.nunique())
    o["projects_with_sprints"] = int(spr.Project_ID.nunique()); o["sprints"] = len(spr)
    o["sprints_dated"] = int(d.sprints.dropna(subset=["start", "end"]).shape[0])
    req = d.issues
    o["requirement_items"] = len(req); o["requirement_in_sprint"] = int(req.Sprint_ID.notna().sum())
    o["requirement_in_sprint_projects"] = int(req[req.Sprint_ID.notna()].Project_ID.nunique())
    o["sprint_changes"] = len(d.changes); o["items_with_sprint_history"] = int(d.changes.Issue_ID.nunique())
    known = set(zip(d.sprints.Project_ID, d.sprints.Name))
    iv = membership_intervals(d, ren)
    iv_known = pd.Series([(p, n) in known for p, n in zip(iv.Project_ID, iv.name)], index=iv.index)
    nost = set(req[req.ID.isin(d.changes.Issue_ID) & req.Sprint_ID.isna()].ID)
    any_known = iv_known[iv.Issue_ID.isin(nost)].groupby(iv.Issue_ID[iv.Issue_ID.isin(nost)]).any()
    o["items_history_no_stored_sprint"] = len(nost)
    o["of_which_only_absent_sprints"] = float(1 - any_known.mean())
    # Section 3.2: which sprint TAWOS keeps
    last = d.changes.groupby("Issue_ID").To_String.last()
    name = dict(zip(d.sprints.ID, d.sprints.Name))
    rows = []
    for i, s in zip(req.ID, req.Sprint_ID):
        if pd.isna(s) or i not in last.index: continue
        lst = _split(last[i])
        if len(lst) >= 2: rows.append((name.get(s) == lst[0], name.get(s) == lst[-1]))
    r = np.array(rows)
    o["items_final_list_2plus"] = len(r); o["stored_is_first"] = float(r[:, 0].mean()); o["stored_is_last"] = float(r[:, 1].mean())
    # Section 3.3: pitfalls
    first = d.changes.groupby("Issue_ID").From_String.first()
    o["unlogged_initial_sprint"] = float(first.map(lambda v: len(_split(v)) > 0).mean())
    app = [0 < len(set(_split(a))) and set(_split(a)) < set(_split(b)) for a, b in zip(d.changes.From_String, d.changes.To_String)]
    o["changes_appending"] = float(np.mean(app))
    g = d.sprints.groupby(["Project_ID", "Name"]).ID.size()
    o["duplicate_names"] = int((g > 1).sum()); o["duplicate_name_sprints"] = int(g[g > 1].sum())
    o["duplicate_name_sprints_share"] = float(g[g > 1].sum() / len(d.sprints)); o["renames"] = len(ren)
    pairs = iv[["Issue_ID", "Project_ID", "name"]].drop_duplicates()
    o["memberships_absent_sprint"] = 1 - float(np.mean([(p, n) in known for p, n in zip(pairs.Project_ID, pairs.name)]))
    return o


def pjd_data(dfirst, dlast, data_first, data_last, ren):
    o = {}
    iss = dfirst.issues
    o["requirement_items_with_sprints_raw"], o["sprint_changes_raw"] = dfirst.raw_counts
    o["duplicated_issues_removed"] = dfirst.raw_counts[0] - len(iss)
    o["duplicated_changes_removed"] = dfirst.raw_counts[1] - len(dfirst.changes)
    o["repositories"] = int(iss.Project_ID.nunique())
    o["sprints"] = len(dfirst.sprints); o["sprints_with_start"] = int(dfirst.sprints.start.notna().sum())
    o["sprints_with_start_and_end"] = int(dfirst.sprints.dropna(subset=["start", "end"]).shape[0])
    st = dict(zip(dfirst.sprints.ID, dfirst.sprints.start))
    fl = pd.DataFrame({"f": dfirst.issues.set_index("ID").Sprint_ID, "l": dlast.issues.set_index("ID").Sprint_ID}).dropna()
    fl["fs"], fl["ls"] = fl.f.map(st), fl.l.map(st)
    fl = fl.dropna(subset=["fs", "ls"]); fl = fl[fl.f != fl.l]
    o["first_last_dated_distinct"] = len(fl); o["first_before_last"] = float((fl.fs < fl.ls).mean())
    # validation: final membership obtained by replaying the change log, ordered by entry time,
    # against the first and last sprint of the stored sprint list
    from tawos_asof.core import FAR_FUTURE
    iv = membership_intervals(dfirst, {})
    fin = iv[iv.t_out == FAR_FUTURE].sort_values("t_in", kind="stable").groupby("Issue_ID").name.agg(["first", "last"])
    sf, sl = dfirst.issues.set_index("ID").Sprint_ID, dlast.issues.set_index("ID").Sprint_ID
    fin = fin[fin.index.isin(sf.dropna().index)]
    o["validation_items"] = len(fin)
    o["replayed_first_matches"] = float((fin["first"] == fin.index.map(sf)).mean())
    o["replayed_last_matches"] = float((fin["last"] == fin.index.map(sl)).mean())
    return o


def pjd_hidden(d, com, tawos_keys):
    o = {}
    it = com.groupby("Issue_ID").Sprint_ID.nunique().to_frame("n"); it["carried"] = it.n >= 2
    raw = pd.read_csv(d._path, low_memory=False).drop_duplicates("ID").set_index("ID")
    it["defect"] = it.index.map(raw.Defect_Linked).astype(float) > 0
    o["items_committed"] = len(it); o["carried_share"] = float(it.carried.mean())
    o["defect_linked"] = [float(it[it.carried].defect.mean()), float(it[~it.carried].defect.mean())]
    o["defect_chi2_p"] = float(stats.chi2_contingency(pd.crosstab(it.carried, it.defect))[1])
    it["P"] = it.index.map(raw.Project_ID); hi = lo = nn = 0
    for _, g in it.groupby("P"):
        if g.carried.any() and (~g.carried).any():
            nn += 1; x, y = g[g.carried].defect.mean(), g[~g.carried].defect.mean(); hi += x > y; lo += x < y
    o["defect_within_repositories"] = {"repositories": nn, "higher": int(hi), "lower": int(lo)}
    return o


def shared(dP, comP, S, finP, tawos_sprint_keys, raw):
    """Projects of the Public Jira Dataset that also have sprints in TAWOS (same Jira key, same organisation)."""
    keys = set(raw.Project_Key.astype(str)) & tawos_sprint_keys
    sh = set(raw[raw.Project_Key.astype(str).isin(keys) & ~((raw.Project_Key == "NEXUS") & (raw.Project_ID == "RedHat"))].index)
    C = comP[comP.Sprint_ID.isin(S.Sprint_ID)]
    out = {"shared_projects": sorted(keys), "shared_share_of_committed_items": float(C.Issue_ID.drop_duplicates().isin(sh).mean())}
    bad = set(C[C.Issue_ID.isin(sh)].Sprint_ID) | set(finP[finP.Issue_ID.isin(sh)].Sprint_ID)
    Se = S[~S.Sprint_ID.isin(bad)]; E = Se[(Se.n_dataset >= 5) & (Se.n_committed >= 5)]
    out.update(excluded_sprints=len(Se), excluded_repositories=int(Se.Project_ID.nunique()),
               excluded_absent=float(Se.carried_out.sum() / Se.n_committed.sum()),
               excluded_success_committed=float((E.completion_committed >= 0.9).mean()),
               excluded_success_dataset=float((E.completion_dataset >= 0.9).mean()))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tawos", required=True); ap.add_argument("--pjd-first", required=True)
    ap.add_argument("--pjd-last", required=True); ap.add_argument("--out", default="paper_numbers.json")
    a = ap.parse_args()
    R = {}
    for g in (1, 0, 3):
        d, ren, com, fin, S = run_tool(a.tawos, g)
        o, C = delivery(d, com, fin, S)
        R[f"tawos_grace_{g}"] = o
        if g == 1:
            R["tawos_rq1_rq2"] = tawos_extra(d, ren, com, fin, S, C, a.tawos)
            R["tawos_data"] = tawos_data(d, a.tawos, ren)
            tp = pd.read_csv(os.path.join(a.tawos, "project.csv")).set_index("ID")
            tawos_keys = set(tp.loc[S.Project_ID.unique(), "Project_Key"].astype(str))
        print(f"TAWOS grace {g} done", flush=True)
    dP = {}
    for rule, path in (("first", a.pjd_first), ("last", a.pjd_last)):
        d, ren, com, fin, S = run_tool(path, 1, dedupe=True)
        d._path = os.path.join(path, "issue.csv"); dP[rule] = d
        o, _ = delivery(d, com, fin, S)
        raw = pd.read_csv(d._path, low_memory=False).drop_duplicates("ID").set_index("ID")
        o.update(shared(d, com, S, fin, tawos_keys, raw))
        if rule == "first":
            R["pjd_hidden_work"] = pjd_hidden(d, com, tawos_keys)
        R[f"pjd_{rule}"] = o
        print(f"PJD {rule} done", flush=True)
    R["pjd_data"] = pjd_data(dP["first"], dP["last"], a.pjd_first, a.pjd_last, {})
    json.dump(R, open(a.out, "w"), indent=1, default=lambda x: x.item() if hasattr(x, "item") else str(x))
    print(json.dumps(R, indent=1, default=lambda x: x.item() if hasattr(x, "item") else str(x)))


if __name__ == "__main__":
    main()
