"""Extract sprint data from the Public Jira Dataset (Montgomery et al., MSR 2022) for the
sprint-scope reconstruction.

The dataset is distributed as one zip file containing a MongoDB dump. This script reads the zip
directly (no MongoDB needed), streams every issue document, and writes small CSV files:

    issue_first.csv   issue table; Sprint_ID = FIRST sprint in the final sprint list (TAWOS rule)
    issue_last.csv    same, with Sprint_ID = LAST sprint in the final list (alternative rule)
    sprint.csv        sprints recovered from the issues' sprint field (id, name, state, dates)
    change_log.csv    every change to the Sprint field (old/new sprint IDs, timestamp)
    diagnostics.txt   what was found, for checking

Usage:
    python -m pip install pymongo
    python extract_publicjira.py "C:\\path\\to\\2025-06-23 ThePublicJiraDataset.zip"
Output: publicjira_extract.zip next to this script.
"""
import csv, gzip, io, os, re, sys, zipfile
from datetime import datetime, timezone
from collections import Counter

try:
    import bson
except ImportError:
    sys.exit("Install pymongo first:  python -m pip install pymongo")

REQ_TYPES = {"story", "task", "improvement", "new feature"}


def norm_date(v):
    """Any Jira date (ISO string with Z/+0000/+00:00, or datetime) -> 'YYYY-MM-DD HH:MM:SS' in UTC."""
    if v in (None, "", "<null>"):
        return None
    if isinstance(v, datetime):
        dt = v
    else:
        s = str(v).strip().replace("Z", "+0000")
        s = re.sub(r"([+-]\d{2}):(\d{2})$", r"\1\2", s)
        dt = None
        for fmt in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
            try:
                dt = datetime.strptime(s, fmt); break
            except ValueError:
                continue
        if dt is None:
            return None
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt.strftime("%Y-%m-%d %H:%M:%S")
SPRINT_STR = re.compile(r"com\.atlassian\.greenhopper\.service\.sprint\.Sprint@\w+\[(.*)\]", re.S)


def parse_sprint_value(v):
    """One sprint value from the issue's sprint field -> dict or None (string or object form)."""
    if isinstance(v, dict) and "id" in v and "name" in v:
        return {"id": str(v.get("id")), "name": v.get("name"), "state": v.get("state"),
                "startDate": v.get("startDate"), "endDate": v.get("endDate"),
                "completeDate": v.get("completeDate"), "boardId": v.get("boardId") or v.get("rapidViewId")}
    if isinstance(v, str):
        m = SPRINT_STR.match(v.strip())
        if not m:
            return None
        body = m.group(1)
        def get(key, stop=r",[a-zA-Z]+="):
            mm = re.search(key + r"=(.*?)(?:" + stop + r"|$)", body, re.S)
            return mm.group(1) if mm else None
        name = re.search(r"name=(.*?),(?:goal|startDate|autoStartStop|incompleteIssuesDestinationId)=", body, re.S)
        val = lambda x: None if x in (None, "<null>", "") else x
        return {"id": val(get("id")), "name": name.group(1) if name else val(get("name")),
                "state": val(get("state")), "startDate": val(get("startDate")), "endDate": val(get("endDate")),
                "completeDate": val(get("completeDate")), "boardId": val(get("rapidViewId"))}
    return None


def sprint_field(fields):
    """Find the custom field that holds sprints; return list of parsed sprints in list order."""
    for k, v in fields.items():
        if not k.startswith("customfield_") or not v or not isinstance(v, list):
            continue
        parsed = [parse_sprint_value(x) for x in v]
        if parsed and all(p is not None and p.get("id") for p in parsed):
            return parsed
    return None


ARCHIVE_MAGIC = 0x8199e26d
TERMINATOR = b"\xff\xff\xff\xff"


def _read_exact(f, n):
    buf = b""
    while len(buf) < n:
        chunk = f.read(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def _read_doc_or_term(f):
    """Return ('term', None), ('doc', dict) or ('eof', None)."""
    head = _read_exact(f, 4)
    if head is None:
        return "eof", None
    if head == TERMINATOR:
        return "term", None
    n = int.from_bytes(head, "little")
    body = _read_exact(f, n - 4)
    if body is None:
        return "eof", None
    return "doc", bson.decode(head + body)


def iter_archive(f, diag):
    """Yield (collection, document) from a mongodump --archive stream (plain or gzip)."""
    magic = _read_exact(f, 4)
    if magic[:2] == b"\x1f\x8b":                      # gzip-compressed archive
        f = gzip.GzipFile(fileobj=_Prepend(magic, f))
        magic = _read_exact(f, 4)
    if int.from_bytes(magic, "little") != ARCHIVE_MAGIC:
        diag.append(f"archive: unexpected magic number {magic.hex()}")
        return
    while True:                                        # prelude: header and metadata, then terminator
        kind, doc = _read_doc_or_term(f)
        if kind != "doc":
            break
    while True:                                        # body: [namespace header, documents..., terminator]*
        kind, hdr = _read_doc_or_term(f)
        if kind == "eof":
            return
        if kind == "term":
            continue
        coll = hdr.get("collection")
        if hdr.get("EOF"):
            _read_doc_or_term(f)                       # terminator after an EOF header
            continue
        while True:
            kind, doc = _read_doc_or_term(f)
            if kind != "doc":
                break
            yield coll, doc
        if kind == "eof":
            return


class _Prepend:
    """File-like object that re-inserts bytes already read in front of a stream."""
    def __init__(self, head, f):
        self.head, self.f = head, f
    def read(self, n=-1):
        if self.head:
            out, self.head = self.head[:n] if n >= 0 else self.head, self.head[n:] if n >= 0 else b""
            if n < 0 or len(out) < n:
                out += self.f.read(-1 if n < 0 else n - len(out))
            return out
        return self.f.read(n)


def iter_bson_members(z):
    for info in z.infolist():
        n = info.filename
        if n.endswith(".bson") or n.endswith(".bson.gz") or n.endswith(".archive") or n.endswith(".archive.gz"):
            if "metadata" in n:
                continue
            yield info


def main(path):
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "publicjira_extract")
    os.makedirs(out_dir, exist_ok=True)
    diag = []
    z = zipfile.ZipFile(path)
    members = list(iter_bson_members(z))
    diag.append(f"zip: {path}\ndata members found: {len(members)}")
    for m in members:
        diag.append(f"  {m.filename}  ({m.file_size/1e6:.1f} MB uncompressed)")

    f_first = open(os.path.join(out_dir, "issue_first.csv"), "w", newline="", encoding="utf-8")
    f_last = open(os.path.join(out_dir, "issue_last.csv"), "w", newline="", encoding="utf-8")
    f_chg = open(os.path.join(out_dir, "change_log.csv"), "w", newline="", encoding="utf-8")
    cols = ["ID", "Issue_Key", "Project_ID", "Project_Key", "Type", "Sprint_ID", "Creation_Date", "Resolution_Date", "Defect_Linked"]
    w_first, w_last = csv.writer(f_first), csv.writer(f_last)
    w_first.writerow(cols); w_last.writerow(cols)
    w_chg = csv.writer(f_chg); w_chg.writerow(["Issue_ID", "Field", "From_String", "To_String", "Creation_Date"])
    sprints = {}
    stats = Counter()

    def documents():
        for m in members:
            raw = z.open(m)
            if ".archive" in m.filename:
                yield from iter_archive(raw, diag)
            else:
                stream = gzip.GzipFile(fileobj=raw) if m.filename.endswith(".gz") else raw
                repo = os.path.basename(m.filename).split(".")[0]
                for d in bson.decode_file_iter(stream):
                    yield repo, d

    per_repo = Counter()
    for repo, doc in documents():
            per_repo[repo] += 1
            if per_repo[repo] % 100000 == 0:
                print(f"  {repo}: {per_repo[repo]:,} documents read", flush=True)
            fields = doc.get("fields")
            if not isinstance(fields, dict):
                stats["docs_without_fields"] += 1
                continue
            stats["issues"] += 1
            itype = ((fields.get("issuetype") or {}).get("name") or "").strip()
            sp = sprint_field(fields)
            hist = ((doc.get("changelog") or {}).get("histories")) or []
            sprint_changes = []
            for h in hist:
                for it in h.get("items") or []:
                    if str(it.get("field", "")).lower() == "sprint":
                        sprint_changes.append((h.get("created"), it.get("from"), it.get("to")))
            if itype.lower() not in REQ_TYPES:
                continue
            stats["requirement_items"] += 1
            if not sp and not sprint_changes:
                continue
            stats["requirement_items_with_sprints"] += 1
            for s in sp or []:
                key = (repo, s["id"])
                if key not in sprints:
                    sprints[key] = s
            uid = f"{repo}:{doc.get('id')}"
            linked = 0
            for ln in fields.get("issuelinks") or []:
                other = ln.get("inwardIssue") or ln.get("outwardIssue") or {}
                if ((other.get("fields") or {}).get("issuetype") or {}).get("name", "").lower() == "bug":
                    linked = 1
            proj = (fields.get("project") or {}).get("key")
            base = [uid, doc.get("key"), repo, proj, itype, None,
                    norm_date(fields.get("created")), norm_date(fields.get("resolutiondate")), linked]
            first = f"{repo}:{sp[0]['id']}" if sp else None
            last = f"{repo}:{sp[-1]['id']}" if sp else None
            w_first.writerow(base[:5] + [first] + base[6:])
            w_last.writerow(base[:5] + [last] + base[6:])
            for created, frm, to in sprint_changes:
                conv = lambda ids: ", ".join(f"{repo}:{x.strip()}" for x in str(ids).split(",") if x and x.strip()) if ids else ""
                w_chg.writerow([uid, "Sprint", conv(frm), conv(to), norm_date(created)])
                stats["sprint_changes"] += 1
    for r, n in sorted(per_repo.items()):
        diag.append(f"  {r}: {n:,} documents read")

    with open(os.path.join(out_dir, "sprint.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["ID", "Name", "Project_ID", "Repo", "Sprint_Name", "State", "Start_Date", "Activated_Date", "End_Date", "Complete_Date", "Board_ID"])
        for (repo, sid), s in sprints.items():
            # Name holds the unique sprint key so that change-log IDs match sprints unambiguously
            w.writerow([f"{repo}:{sid}", f"{repo}:{sid}", repo, repo, s.get("name"), s.get("state"),
                        norm_date(s.get("startDate")), None, norm_date(s.get("endDate")), norm_date(s.get("completeDate")), s.get("boardId")])
    for f in (f_first, f_last, f_chg):
        f.close()
    diag.append("\n" + "\n".join(f"{k}: {v}" for k, v in stats.items()))
    diag.append(f"sprints recovered: {len(sprints)}")
    open(os.path.join(out_dir, "diagnostics.txt"), "w", encoding="utf-8").write("\n".join(diag))
    print("\n".join(diag))
    zpath = out_dir + ".zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zo:
        for fn in os.listdir(out_dir):
            zo.write(os.path.join(out_dir, fn), fn)
    print(f"\nDone. Upload this file: {zpath}  ({os.path.getsize(zpath)/1e6:.1f} MB)")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit('Usage: python extract_publicjira.py "path\\to\\ThePublicJiraDataset.zip"')
    main(sys.argv[1])
