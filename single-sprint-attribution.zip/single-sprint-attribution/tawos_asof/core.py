"""Point-in-time reconstruction of sprint scope in Jira-based datasets such as TAWOS.

TAWOS stores one sprint per issue (in practice the first sprint the issue entered). The Jira change
log, however, records every sprint an issue passed through. This module rebuilds, for every sprint,
the set of issues that were in it when it started, and compares that committed scope with the
single-sprint view that the dataset exposes.

Four pitfalls are handled explicitly (each is covered by a test):
  1. The initial sprint is not logged when an issue is created inside a sprint; it is recovered from
     the FROM value of the issue's first logged sprint change.
  2. Jira keeps closed sprints in the field when an issue is carried over ("S1" -> "S1, S2"); the
     field is replayed as a set, so membership of S1 ends only when S1 leaves the set.
  3. Sprints that share a name within a project cannot be resolved from the history and are excluded.
  4. Renamed sprints are mapped to their current names (rename = a name swap that occurs in a burst
     across several issues, where the old name is unknown and the new one is a known sprint with a
     closely related name).
"""
from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np
import pandas as pd

FAR_FUTURE = pd.Timestamp("2100-01-01")
DEFAULT_TYPES = ("story", "task", "improvement", "new feature")


def _col(df: pd.DataFrame, *names: str) -> str:
    low = {c.lower(): c for c in df.columns}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    raise KeyError(f"none of {names} in {list(df.columns)}")


def _split(value) -> list[str]:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return []
    return [x.strip() for x in str(value).split(",") if x.strip() and x.strip().lower() != "nan"]


@dataclass
class Data:
    issues: pd.DataFrame      # ID, Project_ID, Type, Sprint_ID, created, resolved
    sprints: pd.DataFrame     # ID, Name, Project_ID, start, end
    changes: pd.DataFrame     # Issue_ID, From_String, To_String, date  (sprint field only)


def load(issue_csv: str, sprint_csv: str, change_csv: str, types=DEFAULT_TYPES) -> Data:
    iss = pd.read_csv(issue_csv, low_memory=False)
    issues = pd.DataFrame({
        "ID": iss[_col(iss, "ID")],
        "Project_ID": iss[_col(iss, "Project_ID")],
        "Type": iss[_col(iss, "Type")].astype(str).str.lower(),
        "Sprint_ID": iss[_col(iss, "Sprint_ID")],
        "created": pd.to_datetime(iss[_col(iss, "Creation_Date")], errors="coerce"),
        "resolved": pd.to_datetime(iss[_col(iss, "Resolution_Date")], errors="coerce"),
    })
    if types:
        issues = issues[issues.Type.isin(types)]

    spr = pd.read_csv(sprint_csv)
    start = pd.to_datetime(spr[_col(spr, "Start_Date")], errors="coerce")
    if "activated_date" in {c.lower() for c in spr.columns}:
        start = start.fillna(pd.to_datetime(spr[_col(spr, "Activated_Date")], errors="coerce"))
    # planned end of the time box (known when the sprint starts); actual completion only if missing
    end = pd.to_datetime(spr[_col(spr, "End_Date")], errors="coerce").fillna(
        pd.to_datetime(spr[_col(spr, "Complete_Date")], errors="coerce"))
    # implausible dates (e.g. year 0015, a typo in the source data) are treated as missing; this also makes the
    # result independent of the pandas version (older versions cannot represent such dates at all)
    start = start.where(start.dt.year >= 1990)
    end = end.where(end.dt.year >= 1990)
    sprints = pd.DataFrame({"ID": spr[_col(spr, "ID")], "Name": spr[_col(spr, "Name")].astype(str).str.strip(),
                            "Project_ID": spr[_col(spr, "Project_ID")], "start": start, "end": end})

    ch = pd.read_csv(change_csv, low_memory=False)
    ch = ch[ch[_col(ch, "Field")].astype(str).str.lower().str.strip() == "sprint"]
    changes = pd.DataFrame({"Issue_ID": ch[_col(ch, "Issue_ID")],
                            "From_String": ch[_col(ch, "From_String")],
                            "To_String": ch[_col(ch, "To_String")],
                            "date": pd.to_datetime(ch[_col(ch, "Creation_Date")], errors="coerce")})
    changes = changes[changes.Issue_ID.isin(issues.ID)].dropna(subset=["date"]).sort_values("date", kind="stable")
    return Data(issues, sprints, changes)


def ambiguous_sprints(sprints: pd.DataFrame) -> set:
    """Sprint IDs whose (project, name) is shared with another sprint (pitfall 3)."""
    size = sprints.groupby(["Project_ID", "Name"]).ID.transform("size")
    return set(sprints.loc[size > 1, "ID"])


def detect_renames(d: Data, min_issues: int = 2) -> dict:
    """Map (project, old_name) -> new_name for genuine renames (pitfall 4)."""
    known = set(zip(d.sprints.Project_ID, d.sprints.Name))
    proj = dict(zip(d.issues.ID, d.issues.Project_ID))
    rows = []
    for c in d.changes.itertuples(index=False):
        a, b = set(_split(c.From_String)), set(_split(c.To_String))
        rem, add = a - b, b - a
        if len(rem) == 1 and len(add) == 1:
            rows.append((proj.get(c.Issue_ID), next(iter(rem)), next(iter(add)), c.Issue_ID))
    if not rows:
        return {}
    sw = pd.DataFrame(rows, columns=["Project_ID", "old", "new", "Issue_ID"])
    g = sw.groupby(["Project_ID", "old", "new"]).Issue_ID.nunique().reset_index(name="issues")
    digits = lambda s: tuple(re.findall(r"\d+", s))
    def related(o, n):
        o2, n2 = o.lower(), n.lower()
        return n2.startswith(o2) or o2.startswith(n2) or (len(digits(o)) > 0 and digits(o) == digits(n))
    mask = np.array([(p, o) not in known and (p, n) in known and related(o, n)
                     for p, o, n in zip(g.Project_ID, g.old, g.new)], dtype=bool)
    g = g[mask & (g.issues >= min_issues).to_numpy()]
    g = g.sort_values("issues", ascending=False).drop_duplicates(["Project_ID", "old"])
    return {(p, o): n for p, o, n in zip(g.Project_ID, g.old, g.new)}


def membership_intervals(d: Data, renames: dict | None = None) -> pd.DataFrame:
    """One row per (issue, sprint name, interval) during which the sprint was in the issue's sprint field."""
    renames = renames or {}
    proj = dict(zip(d.issues.ID, d.issues.Project_ID))
    created = dict(zip(d.issues.ID, d.issues.created))

    def canon(p, n):
        for _ in range(10):
            if (p, n) not in renames:
                break
            n = renames[(p, n)]
        return n

    out = []
    for iid, g in d.changes.groupby("Issue_ID", sort=False):
        p = proj.get(iid)
        # pitfall 1: initial sprint is not logged; recover it from the first FROM value
        cur = {canon(p, n) for n in _split(g.From_String.iloc[0])}
        since = {n: created.get(iid, g.date.iloc[0]) for n in cur}
        for c in g.itertuples(index=False):
            new = {canon(p, n) for n in _split(c.To_String)}      # pitfall 2: replay as a set
            for n in new - cur:
                since[n] = c.date
            for n in cur - new:
                out.append((iid, p, n, since.pop(n), c.date))
            cur = new
        for n in cur:
            out.append((iid, p, n, since[n], FAR_FUTURE))
    return pd.DataFrame(out, columns=["Issue_ID", "Project_ID", "name", "t_in", "t_out"])


def committed_scope(d: Data, grace_days: float = 1.0, renames: dict | None = None) -> pd.DataFrame:
    """(Issue_ID, Sprint_ID) pairs for issues that were in the sprint at its start (+ grace period)."""
    amb = ambiguous_sprints(d.sprints)
    spr = d.sprints[~d.sprints.ID.isin(amb)].dropna(subset=["start", "end"])
    iv = membership_intervals(d, renames)
    iv = iv.merge(spr.rename(columns={"ID": "Sprint_ID", "Name": "name"})[["Sprint_ID", "name", "Project_ID", "start"]],
                  on=["name", "Project_ID"])
    t = iv.start + pd.Timedelta(days=grace_days)
    logged = iv[(iv.t_in <= t) & (iv.t_out > t)][["Issue_ID", "Sprint_ID"]]
    # issues with no sprint history: assume they belonged to their dataset sprint if created before its start
    nolog = d.issues[~d.issues.ID.isin(d.changes.Issue_ID) & d.issues.Sprint_ID.notna()]
    nolog = nolog.merge(spr[["ID", "start"]].rename(columns={"ID": "Sprint_ID"}), on="Sprint_ID")
    nolog = nolog[nolog.created <= nolog.start + pd.Timedelta(days=grace_days)]
    nolog = nolog.rename(columns={"ID": "Issue_ID"})[["Issue_ID", "Sprint_ID"]]
    return pd.concat([logged, nolog]).drop_duplicates().reset_index(drop=True)


def dataset_scope(d: Data) -> pd.DataFrame:
    """(Issue_ID, Sprint_ID) pairs as stored in the dataset (one sprint per issue)."""
    amb = ambiguous_sprints(d.sprints)
    s = d.issues[d.issues.Sprint_ID.notna() & ~d.issues.Sprint_ID.isin(amb)]
    return s.rename(columns={"ID": "Issue_ID"})[["Issue_ID", "Sprint_ID"]].reset_index(drop=True)


def sprint_summary(d: Data, committed: pd.DataFrame, final: pd.DataFrame,
                   success_threshold: float = 0.9, tolerance_hours: float = 24) -> pd.DataFrame:
    """Per-sprint comparison of the committed scope with the dataset scope."""
    spr = d.sprints.set_index("ID")
    res = dict(zip(d.issues.ID, d.issues.resolved))
    keep = set(committed.Sprint_ID) & set(final.Sprint_ID)

    def view(df, tag):
        x = df[df.Sprint_ID.isin(keep)].copy()
        x["done"] = [res.get(i) is not None and pd.notna(res.get(i)) and
                     res.get(i) <= spr.at[s, "end"] + pd.Timedelta(hours=tolerance_hours)
                     for i, s in zip(x.Issue_ID, x.Sprint_ID)]
        return x.groupby("Sprint_ID").agg(**{f"n_{tag}": ("Issue_ID", "size"), f"completion_{tag}": ("done", "mean")})

    out = view(committed, "committed").join(view(final, "dataset"), how="inner")
    c_pairs = set(zip(committed.Issue_ID, committed.Sprint_ID))
    f_pairs = set(zip(final.Issue_ID, final.Sprint_ID))
    out["carried_out"] = [sum((i, s) not in f_pairs for i in committed.Issue_ID[committed.Sprint_ID == s]) for s in out.index]
    out["added_after_start"] = [sum((i, s) not in c_pairs for i in final.Issue_ID[final.Sprint_ID == s]) for s in out.index]
    out["success_committed"] = out.completion_committed >= success_threshold
    out["success_dataset"] = out.completion_dataset >= success_threshold
    out = out.join(spr[["Name", "Project_ID", "start", "end"]])
    return out.reset_index().rename(columns={"index": "Sprint_ID"})


def field_value_at(changes: pd.DataFrame, final_value, t) -> object:
    """Value of a single-valued field at time t: the FROM of its first change after t, else its final value.

    `changes` holds one issue's changes of one field (columns From_String, date).
    """
    later = changes[changes.date > t].sort_values("date")
    return later.From_String.iloc[0] if len(later) else final_value
