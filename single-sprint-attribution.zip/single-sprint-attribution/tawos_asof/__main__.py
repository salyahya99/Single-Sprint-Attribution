"""Command line: python -m tawos_asof --data DIR --out DIR [--grace-days 1]

DIR must contain issue.csv, sprint.csv and change_log.csv (sprint-field rows with From_String,
To_String and Creation_Date), as produced by the extraction scripts.
"""
import argparse, json, os
from .core import load, detect_renames, committed_scope, dataset_scope, sprint_summary, membership_intervals


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--grace-days", type=float, default=1.0)
    ap.add_argument("--all-types", action="store_true", help="include all issue types, not only requirements")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    d = load(os.path.join(a.data, "issue.csv"), os.path.join(a.data, "sprint.csv"),
             os.path.join(a.data, "change_log.csv"), types=None if a.all_types else ("story", "task", "improvement", "new feature"))
    ren = detect_renames(d)
    iv = membership_intervals(d, ren)
    com = committed_scope(d, a.grace_days, ren)
    fin = dataset_scope(d)
    summ = sprint_summary(d, com, fin)
    iv.to_csv(os.path.join(a.out, "membership_intervals.csv"), index=False)
    com.to_csv(os.path.join(a.out, "committed_scope.csv"), index=False)
    summ.to_csv(os.path.join(a.out, "sprint_summary.csv"), index=False)
    s = {"sprints": int(len(summ)), "renames_resolved": len(ren),
         "committed_items_carried_out_share": float(summ.carried_out.sum() / summ.n_committed.sum()),
         "dataset_items_added_after_start_share": float(summ.added_after_start.sum() / summ.n_dataset.sum()),
         "completion_dataset": float((summ.completion_dataset * summ.n_dataset).sum() / summ.n_dataset.sum()),
         "completion_committed": float((summ.completion_committed * summ.n_committed).sum() / summ.n_committed.sum()),
         "success_rate_dataset (n>=5)": float(summ[(summ.n_dataset >= 5) & (summ.n_committed >= 5)].success_dataset.mean()),
         "success_rate_committed (n>=5)": float(summ[(summ.n_dataset >= 5) & (summ.n_committed >= 5)].success_committed.mean())}
    json.dump(s, open(os.path.join(a.out, "summary.json"), "w"), indent=1)
    for k, v in s.items():
        print(f"{k}: {v:.3f}" if isinstance(v, float) else f"{k}: {v}")


if __name__ == "__main__":
    main()
